class Student(object):

    def __init__(self, first_name, last_name, course, id, birth_date):

        # initialize the student attributes from parameters
        self.first_name = first_name
        self.last_name = last_name
        self.course = course
        self.id = id
        self.birth_date_str = birth_date  # string birth date in form "mm/dd/2014"

        # set default attributes
        self.absentDates = []   # a list of the days the student was absent
        self.marks = []

    def print_fullname(self):
        # prints the full name of the student in the form "last_name, first_name)
        print self.last_name + ", " + self.first_name

    def print_label(self):
        # print a basic label of student info
        print "Name: " + self.last_name + ", " + self.first_name
        print "Course: " + self.course
        print "ID: " + self.id


    def add_mark(self, new_mark):
        # append a new mark to the list of marks
        self.marks.append(new_mark)

    def get_average(self):
        # return the average of the marks
        marks_total = 0
        for mark in self.marks:
            marks_total = marks_total + mark

        average = float(marks_total)/len(self.marks)

        return average


    def add_absence(self,date_str):
        # add a date (in form MM/DD/YYYY) to the absent dates list
        self.absentDates.append(date_str)

    def get_totalAbsences(self):
        # return the number of absences
        return len(self.absentDates)

    def getBirthYear(self):
        # return the birth year in an int
        pass #see implementation in examples below

student1 = Student("Stinky", "McGee","ICS4U","007","April Fools!")

print student1.print_fullname()
print student1.print_label()
student1.add_mark(100)
student1.add_absence("March 4")
print student1.get_average()
print student1.get_totalAbsences()
